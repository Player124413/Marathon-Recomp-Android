#pragma once

#include <Marathon.inl>
#include <Sonicteam/MyRenderProcess.h>

namespace Sonicteam::RenderAction
{
    class CopyTexture : public MyRenderProcess
    {
    public:
        MARATHON_INSERT_PADDING(0x4);
        xpointer<SoX::Graphics::Texture> m_pTexture;
        MARATHON_INSERT_PADDING(0x4);
    };

    MARATHON_ASSERT_OFFSETOF(CopyTexture, m_pTexture, 0x3C);
    MARATHON_ASSERT_SIZEOF(CopyTexture, 0x44);
}
